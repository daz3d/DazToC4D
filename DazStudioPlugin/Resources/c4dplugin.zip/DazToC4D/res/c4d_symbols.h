// C4D-Plugin Symbols

enum
{
	PLUGIN_ID    = 10336071,
	IDS_AUTH                                        = 40000,
	IDS_AUTH_DIALOG                                 = 40001,
	DLG_AUTH                                        = 41000,
	IDC_SERIAL                                      = 41001,
	IDC_SUBMIT                                      = 41002,
	IDC_CANCEL                                      = 41003,
	IDC_CODEBOX                                     = 41004,
	IDC_CODEBOX_AUTH                                = 41005,
	IDC_PASTESERIAL                                 = 41007,
    
// End of symbol definition
  _DUMMY_ELEMENT_
};